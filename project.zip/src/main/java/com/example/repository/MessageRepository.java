package com.example.repository;

public interface MessageRepository {
}
